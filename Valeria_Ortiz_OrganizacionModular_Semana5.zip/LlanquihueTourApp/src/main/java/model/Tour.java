package model;

//atributos
public class Tour {
    private String nombre;
    private String tipo;
    private int precio;
    private String tiposComidas;

//constructor
    public Tour (String nombre, String tipo, int precio, String tiposComidas){
      this.nombre = nombre;
      this.tipo = tipo;
      this.precio = precio;
      this.tiposComidas = tiposComidas;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPrecio() {
        return precio;
    }

    public String getTiposComidas() {
        return tiposComidas;
    }

    public void setTiposComidas(String tiposComidas) {
        this.tiposComidas = tiposComidas;
    }

    public void setPrecio(int precio) {
        this.precio = precio;


    }
    @Override
        public String toString(){
        return "nombre: " + nombre + ", tipo: " + tipo + ", precio: " + precio + ", tipos de comida: " + tiposComidas;

        }

}
