package data;

import model.Tour;

import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class GestorDatos {

    //lista de tours
    ArrayList<Tour> tours = new ArrayList<>();

    //con esto cargo el archivo
    public void cargarDesdeArchivo(String nombreArchivo) {

        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {

            String linea;
//verifico que haya lineas en el archivo
            while ((linea = br.readLine()) != null) {
//con split separo cada linea: "caminata;playa..."
                String[] datos = linea.split(";");
                //verifico que sean igual a 4 datos
                if (datos.length == 4) {
                    //gracias al split convierto la linea en los sgte:
                    Tour tour = new Tour(
                            datos[0],
                            datos[1],
                            Integer.parseInt(datos[2]), //precio
                            datos[3]
                    );
                    tours.add(tour);  //creo un objeto tour
                }
            }
                System.out.println("Archivo cargado correctamente");

            } catch (IOException e) {
                System.out.println("Error al leer archivo: " + e.getMessage());
            }
        }
//ahora pido la lista de tours que cargué
    public ArrayList<Tour> getTours() {
        return tours;
}
}
