package app;

import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.FileWriter;
import data.GestorDatos;
import model.Tour;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {

        //para cargar archivo:

        GestorDatos gd = new GestorDatos();
        gd.cargarDesdeArchivo("tour.txt");

        //me traigo los tours que se cargaron

        ArrayList<Tour> tours = gd.getTours();

        System.out.println("Listado de tours cargados:");

//muestro todos los tours
        for (Tour to : tours) {
            System.out.println(to);
        }


        //destino a eliminar:

       String destinoBuscar = "escalada";

//para eliminarlo:
        tours.removeIf(t -> t.getTipo().equals(destinoBuscar));

        //se muestran todos sin el eliminado

        System.out.println("Listado después de eliminar:");
        for (Tour t : tours) {
            System.out.println(t);
        }

        //para guardar archivo:
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("tour.txt"))){
        for (Tour tour : tours) {
            bw.write(tour.toString());
            bw.newLine();
        }

        System.out.println("Archivo tour.txt guardado correctamente.");

    } catch (IOException e) {
        System.out.println("Error al guardar el archivo: " + e.getMessage());
    }

}
}
